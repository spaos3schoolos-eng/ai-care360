
const API_URL = "https://script.google.com/macros/s/AKfycbwAeCxBYRIQheUJalCbRdklt7SH0gQmDmkkirMIVt3ylNoDwhkFnfZFxvdUbmk0TTOsjA/exec";
const CACHE_KEY = "assessments";
const CACHE_TIME_KEY = "assessmentsUpdatedAt";

function readAssessmentCache() {
  try {
    const cached = JSON.parse(localStorage.getItem(CACHE_KEY) || "[]");
    return Array.isArray(cached) ? cached : [];
  } catch (e) {
    return [];
  }
}

function writeAssessmentCache(list) {
  localStorage.setItem(CACHE_KEY, JSON.stringify(list));
  localStorage.setItem(CACHE_TIME_KEY, String(Date.now()));
}

async function syncAssessments(options = {}) {
  const { timeoutMs = 5000, force = false } = options;
  const last = Number(localStorage.getItem(CACHE_TIME_KEY) || 0);

  // ไม่ยิง API ซ้ำ ถ้าเพิ่ง sync ภายใน 60 วินาที
  if (!force && Date.now() - last < 60000 && readAssessmentCache().length) {
    return readAssessmentCache();
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(API_URL, {
      cache: "no-store",
      signal: controller.signal
    });

    if (!response.ok) throw new Error("HTTP " + response.status);

    const result = await response.json();
    const list = Array.isArray(result)
      ? result
      : (result && Array.isArray(result.data) ? result.data : null);

    if (!list) throw new Error(result?.message || "รูปแบบข้อมูล API ไม่ถูกต้อง");

    writeAssessmentCache(list);
    window.dispatchEvent(new CustomEvent("assessments-updated", { detail: list }));
    return list;
  } finally {
    clearTimeout(timeout);
  }
}

function initUser() {
  const user = JSON.parse(localStorage.getItem("loginUser") || "null");
  if (!user) {
    alert("กรุณาเข้าสู่ระบบ");
    location.href = "login.html";
    return null;
  }

  const role = document.getElementById("userRole");
  if (role) role.textContent = user.role === "admin" ? "ผู้ดูแลระบบ" : "ครู";

  const setting = document.getElementById("settingMenu");
  if (setting && user.role !== "admin") setting.style.display = "none";

  return user;
}

function logout() {
  localStorage.removeItem("loginUser");
  location.href = "../index.html";
}
