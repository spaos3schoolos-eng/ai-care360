AI CARE 360 - FAST CACHE
ไฟล์ที่แก้:
- common.js
- dashboard.html
- student.html
- statistics.html
- risk.html
- report.html

ให้อัปโหลดไฟล์ทั้งหมดไว้ในโฟลเดอร์ pages เดียวกัน
ระบบจะแสดงข้อมูลจาก localStorage ทันที และ sync Google Apps Script เบื้องหลัง
API timeout 5 วินาที และไม่ยิง API ซ้ำภายใน 60 วินาที

หมายเหตุ:
assessment.html และ setting.html ไม่ได้ถูกสร้างใหม่ เพราะยังไม่มี source ฉบับเต็มในชุดโค้ดที่ใช้สร้างไฟล์นี้
